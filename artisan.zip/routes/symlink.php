<?php
symlink('/spacebar/storage/app/public', '/public_html/storage/');