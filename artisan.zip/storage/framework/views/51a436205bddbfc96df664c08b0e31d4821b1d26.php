<?php if(Session::has('success')): ?>
<!--begin::Alert-->
<div class="alert alert-dismissible bg-success d-flex flex-column flex-sm-row">
    <!--begin::Wrapper-->
    <div class="d-flex flex-column text-light pe-0 pe-sm-10">
        <!--begin::Title-->
        <h5 class="mb-2 light text-white">Good Job!</h4>
        <!--end::Title-->

        <!--begin::Content-->
        <span><?php echo e(Session::get('success')); ?></span>
        <!--end::Content-->
    </div>
    <!--end::Wrapper-->

</div>
<!--end::Alert-->
<?php endif; ?>
<?php /**PATH C:\laragon\www\spacebar-book-system\resources\views/templates/success.blade.php ENDPATH**/ ?>