
<?php $__env->startSection('page-title', 'Booking Form'); ?>
<?php $__env->startPrepend('page-css'); ?>
<link href="/admin-assets/libs/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
<link href="/admin-assets/libs/bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet">
<?php $__env->stopPrepend(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('templates.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<form action="<?php echo e(route('user.booking.book', [$room->id])); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="card shadow-none">
        <div class="card-header fs-5 text-dark">Book Information</div>
        <div class="card-body">
            <div class="card-body p-9">
                <div class="row">
                    <label class="col-lg-4 col-form-label text-dark text-dark">
                        <span class="">Room Name</span>
                    </label>

                    <div class="col-lg-8 mb-3">
                        <input type="text" id="input-room-name" disabled class="form-control"
                            value="<?php echo e($room->name); ?>" />
                    </div>
                </div>

                <div class="row">
                    <label class="col-lg-4 col-form-label text-dark">
                        <span class="">Price (per day)</span>
                    </label>

                    <div class="col-lg-8 mb-3">
                        <input type="text" id="pricePerDay" disabled class="form-control" value="<?php echo e($room->price); ?>" />
                    </div>
                </div>

                <div class="row">
                    <label class="col-lg-4 col-form-label text-dark">
                        <span class="">Classification</span>
                    </label>

                    <div class="col-lg-8 mb-3">
                        <input type="text" disabled class="form-control" value="<?php echo e($room->roomType->type_name); ?>" />
                    </div>
                </div>

                <div class="row">
                    <label class="col-lg-4 col-form-label text-dark">
                        <span class="">Capacity</span>
                    </label>

                    <div class="col-lg-8 mb-3">
                        <input disabled type="text" class="form-control" value="<?php echo e($room->capacity); ?>" />
                    </div>
                </div>

                <div class="row">
                    <label class="col-lg-4 col-form-label text-dark">
                        <span class="
                                    ">Description</span>
                    </label>

                    <div class="col-lg-8 mb-3">
                        <textarea class="form-control" id="input-room-description" style="resize:none;"
                            disabled><?php echo e($room->description); ?></textarea>
                    </div>
                </div>

                <div class="row">
                    <label class="col-lg-4 col-form-label text-dark">
                        <span class="">Duration</span>
                    </label>

                    <div class="col-lg-8 mb-3">
                        <div class="input-daterange input-group" id="datepicker6" data-provide="datepicker"
                            data-date-container='#datepicker6'>
                            <input type="text" class="form-control" name="start" placeholder="Check In" />
                            <input type="text" class="form-control" name="end" placeholder="Check Out" />
                        </div>
                    </div>
                </div>

                <div class="row">
                    <label class="col-lg-4 col-form-label text-dark">
                        <span class="">Extras</span>
                    </label>

                    <div class="col-lg-8 mb-3">
                        <select class="form-control select2" multiple name="extras[]">
                            <?php $__currentLoopData = $extras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $extra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($extra->id); ?>"><?php echo e($extra->name); ?> - <?php echo e($extra->price); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <div class="float-end">
                    <button type="submit" class="btn btn-primary btn-lg waves-effect waves-light">Proceed to
                        billing</button>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
</form>
<?php $__env->startPush('page-scripts'); ?>
<script src="/admin-assets/libs/select2/js/select2.min.js"></script>
<script src="/admin-assets/libs/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
<script src="/admin-assets/js/pages/form-advanced.init.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\spacebar-book-system\resources\views/user/book-form.blade.php ENDPATH**/ ?>