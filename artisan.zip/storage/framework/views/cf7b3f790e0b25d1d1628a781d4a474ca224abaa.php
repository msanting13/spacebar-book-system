
<?php $__env->startSection('page-title', 'Add new content'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('templates.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
    <div class="col-md-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <?php if($errors->any()): ?>
                    <div class='alert alert-danger'>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <?php echo e($error); ?>

                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
                <form action="<?php echo e(route('admin.page.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group mb-5">
                        <label>Title</label>
                        <input type="text" name="title" class="form-control" value="<?php echo e(old('title')); ?>" placeholder="Enter title">
                    </div>

                    <div class="form-group">
                        <label>Content</label>
                        <textarea name="content" class='form-control' cols="30" rows="10" placeholder="Enter content"><?php echo e(old('content')); ?></textarea>
                    </div>

                    <div class="form-group mt-3">
                        <div class="float-end">
                            <input type="submit" class='btn btn-primary' value='Submit new content'>
                        </div>
                    </div>

                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->startPush('page-scripts'); ?>
<script src="https://cdn.ckeditor.com/4.17.1/standard/ckeditor.js"></script>
<script>
    CKEDITOR.replace( 'content' );
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\spacebar-book-system\resources\views/admin/page/create.blade.php ENDPATH**/ ?>