
<?php $__env->startSection('page-title', 'Your Account'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('templates.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('templates.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="card">
    <div class="card-header fs-5 text-dark">
        Sign-in Credentials
    </div>
    <div class="card-body">
        <form action="<?php echo e(route('user.update.password', $user->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div>
                <!--begin::Card body-->
                <div class="card-body border-top p-9">
                    <div class="row">
                        <!--begin::Label-->
                        <label class="col-lg-4 col-form-label">
                            <span class="required text-dark">Email Address </span>
                        </label>
                        <!--end::Label-->
                        <!--begin::Col-->
                        <div class="col-lg-8 mb-3">
                            <input type="tel" name="email" class="form-control" placeholder=""
                                value="<?php echo e(old('email', $user->email)); ?>">
                            <div class="fv-plugins-message-container invalid-feedback">
                                <?php echo e($errors->first('email')); ?>

                            </div>
                        </div>
                        <!--end::Col-->
                    </div>

                    <div class="row">
                        <!--begin::Label-->
                        <label class="col-lg-4 col-form-label">
                            <span class="text-dark">Current password <span class='text-danger'>*</span></span>
                        </label>
                        <!--end::Label-->
                        <!--begin::Col-->
                        <div class="col-lg-8 mb-3">
                            <input type="tel" name="currentPassword" class="form-control" placeholder="" value="">
                            <div class="fv-plugins-message-container invalid-feedback">
                                <?php echo e($errors->first('currentPassword')); ?>

                            </div>
                        </div>
                        <!--end::Col-->
                    </div>

                    <div class="row">
                        <!--begin::Label-->
                        <label class="col-lg-4 col-form-label">
                            <span class="text-dark">New Password <span class='text-danger'>*</span></span>
                        </label>
                        <!--end::Label-->
                        <!--begin::Col-->
                        <div class="col-lg-8 mb-3">
                            <input type="tel" name="password" class="form-control" placeholder="" value="">
                            <div class="fv-plugins-message-container invalid-feedback">
                                <?php echo e($errors->first('password')); ?>

                            </div>
                        </div>
                        <!--end::Col-->
                    </div>

                    <div class="row">
                        <!--begin::Label-->
                        <label class="col-lg-4 col-form-label">
                            <span class="text-dark">Re-type new password <span class='text-danger'>*</span></span>
                        </label>
                        <!--end::Label-->
                        <!--begin::Col-->
                        <div class="col-lg-8">
                            <input type="tel" name="password_confirmation" class="form-control" placeholder="" value="">
                            <div class="fv-plugins-message-container invalid-feedback">
                                <?php echo e($errors->first('password_confirmation')); ?>

                            </div>
                        </div>
                        <!--end::Col-->
                    </div>
                </div>

                <div class="float-end">
                    <button type="submit" class="btn btn-success">Save Changes</button>
                </div>
                <div class="clearfix"></div>
                <!--end::Card body-->

            </div>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-header fs-5 text-dark">
        Basic Information
    </div>
    <div class="card-body">
        <form method="POST" action="<?php echo e(route('user.profile.update', Auth::user()->id)); ?>" class="form fv-plugins-bootstrap5 fv-plugins-framework">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                            <!--begin::Card body-->
                            <div class="card-body p-9">
                                <!--begin::Input group-->
                                <div class="row mb-6">
                                    <!--begin::Label-->
                                    <label class="col-lg-4 col-form-label text-dark">Full Name</label>
                                    <!--end::Label-->
                                    <!--begin::Col-->
                                    <div class="col-lg-8">
                                        <!--begin::Row-->
                                        <div class="row">
                                            <!--begin::Col-->
                                            <div class="col-lg-6 ">
                                                <input type="text" name="first_name"
                                                    class="form-control"
                                                    placeholder="First name"
                                                    value="<?php echo e(old('firstname', $user->first_name)); ?>">
                                                <div class="fv-plugins-message-container invalid-feedback"></div>
                                            </div>
                                            <!--end::Col-->
                                            <!--begin::Col-->
                                            <div class="col-lg-6 ">
                                                <input type="text" name="last_name"
                                                    class="form-control"
                                                    placeholder="Last name"
                                                    value="<?php echo e(old('last_name', $user->last_name)); ?>">
                                                <div class="fv-plugins-message-container invalid-feedback"></div>
                                            </div>
                                            <!--end::Col-->
                                        </div>
                                        <!--end::Row-->
                                    </div>
                                    <!--end::Col-->
                                </div>
                                <!--end::Input group-->
                                <!--begin::Input group-->
                                <div class="row">
                                    <!--begin::Label-->
                                    <label class="col-lg-4 col-form-label">
                                        <span class="required text-dark">Mobile No.</span>
                                    </label>
                                    <!--end::Label-->
                                    <!--begin::Col-->
                                    <div class="col-lg-8 mt-3">
                                        <input type="tel" name="phone_number"
                                            class="form-control"
                                            placeholder="Phone number"
                                            value="<?php echo e(old('phone_number', $user->phone_number)); ?>">
                                        <div class="fv-plugins-message-container invalid-feedback"></div>
                                    </div>
                                    <!--end::Col-->
                                </div>
                                <!--end::Input group-->

                                <!--begin::Input group-->
                                <div class="row">
                                    <!--begin::Label-->
                                    <label class="col-lg-4 col-form-label">
                                        <span class="required text-dark">Address</span>
                                    </label>
                                    <!--end::Label-->
                                    <!--begin::Col-->
                                    <div class="col-lg-8 mt-3">
                                        <textarea name="address"
                                            class="form-control"><?php echo e(Str::title(old('address', $user->address))); ?></textarea>
                                        <div class="fv-plugins-message-container invalid-feedback"></div>
                                    </div>
                                    <!--end::Col-->
                                </div>
                                <!--end::Input group-->
                            </div>
                            <!--end::Card body-->
                            <div class="float-end">
                            <button type="submit" class="btn btn-success">Save
                                    Changes</button>
                            </div>
                            <div class="clearfix"></div>
                        </form>
                        <!--end::Form-->
                    </div>
                    <!--end::Content-->

                </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\spacebar-book-system\resources\views/user/user-profile.blade.php ENDPATH**/ ?>