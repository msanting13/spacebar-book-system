
<?php $__env->startSection('content'); ?>
<script>
    const options = {
  method: 'POST',
  headers: {
    Accept: 'application/json',
    'Content-Type': 'application/json',
    Authorization: 'Basic cGtfdGVzdF9URnZQRzRQSDk1QzVBRDlvYXZ3NXg5NWI6c2tfdGVzdF9kYXA3NUhCazRGZGhadEE4ZDJOZEUyMWY='
  },
  body: JSON.stringify({
    data: {
      attributes: {
        amount: 10000,
        redirect: {
          success: 'http://localhost:8000/success',
          failed: 'http://localhost:8000/failed'
        },
        type: 'gcash',
        currency: 'PHP'
      }
    }
  })
};

fetch('https://api.paymongo.com/v1/sources', options)
  .then(response => response.json())
  .then(response => {
      window.open(response.data.attributes.redirect.checkout_url);
  })
  .catch(err => console.error(err));
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\spacebar-book-system\resources\views/user/payment.blade.php ENDPATH**/ ?>