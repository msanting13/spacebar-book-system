<nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('home')); ?>">
          <i class="mdi mdi-home menu-icon"></i>
          <span class="menu-title">Home</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('user.booking.index')); ?>">
          <i class="mdi mdi-book menu-icon"></i>
          <span class="menu-title">Booking</span>
        </a>
      </li>
    </ul>
  </nav>

  <?php /**PATH C:\laragon\www\spacebar-book-system\resources\views/user/layouts/partials/sidebar.blade.php ENDPATH**/ ?>