
<?php $__env->startSection('page-title', 'User Profile'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('templates.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
    <div class="col-md-12 grid-margin stretch-card">
    
      <div class="card">
        <div class="card-body">
        <?php if($errors->any()): ?>
            <div class='alert alert-danger text-dark'>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <?php echo e($error); ?>

                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
          <h4 class="card-title">Account Information</h4>
          <form class="forms-sample" action="<?php echo e(route('admin.user.update', $user->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group mb-5">
              <label for="firstname">Firstname</label>
              <input type="text" class="form-control" name="firstname" id="firstname" placeholder="Firstname" value="<?php echo e(old('firstname', $user->first_name)); ?>">
            </div>
            <div class="form-group mb-5">
              <label for="lastname">Lastname</label>
              <input type="text" class="form-control" name="lastname" id="lastname" placeholder="Lastname" value="<?php echo e(old('lastname', $user->last_name)); ?>">
            </div>

            <div class="form-group mb-5">
              <label for="email">Email address</label>
              <input type="email" class="form-control" name="email" id="email" placeholder="Email" value="<?php echo e(old('email', $user->email)); ?>">
            </div>

            <div class="form-group mb-5">
              <label for="phone_number">Phone Number</label>
              <input type="text" class="form-control" name="phone_number" id="phone_number" placeholder="Phone Number" value="<?php echo e(old('phone_number', $user->phone_number)); ?>">
            </div>
            
            <div class="float-end">
                <button type="submit" class="btn btn-success me-2">Save</button>
            </div>
          </form>
        </div>
      </div>
    </div>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\spacebar-book-system\resources\views/admin/user/edit.blade.php ENDPATH**/ ?>