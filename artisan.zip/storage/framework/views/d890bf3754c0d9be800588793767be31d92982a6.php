
<?php $__env->startSection('page-title', 'Dashboard'); ?>
<?php $__env->startPrepend('page-css'); ?>
<!-- DataTables -->
<link href="/admin-assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
<link href="/admin-assets/libs/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css" rel="stylesheet"
    type="text/css" />

<!-- Responsive datatable examples -->
<link href="/admin-assets/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css" rel="stylesheet"
    type="text/css" />
<?php $__env->stopPrepend(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('templates.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="card shadow-none">
    <div class="card-body">
        <table id="bookings_table" class="table table-bordered text-dark">
            <thead>
                <tr class="fw-boldest fs-6 text-uppercase px-7">
                    <th>Invoice #</th>
                    <th class='text-center'>Name</th>
                    <th>Type</th>
                    <th>Capacity</th>
                    <th>Price</th>
                    <th class='text-center'>Status</th>
                    <th class='text-center'>Duration/s</th>
                    <th class='text-center' nowrap>Paid Down Payment</th>
                    <th class='text-center'>Booked At</th>
                    <th class='text-center'>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class='align-middle'>
                    <td class='fs-5 text-center'>
                        <a target="_blank" href="<?php echo e(route('user.view.invoice', $booking->id)); ?>" class='text-info text-decoration-underline'><?php echo e($booking->invoices->invoice_number); ?></a>
                    </td>
                    <td class='fs-5 text-center'><?php echo e($booking->room->name); ?></td>
                    <td class='fs-5 text-center'><?php echo e($booking->room->roomType->type_name); ?></td>
                    <td class='fs-5 text-center'><?php echo e($booking->room->capacity); ?></td>
                    <td class='fs-5 text-center'><?php echo e($booking->total_price); ?></td>
                    <td class='text-center'>
                        <span class='badge bg-primary text-uppercase fs-6'>
                            <?php echo e($booking->status); ?>

                        </span>
                    </td>
                    <td class='fs-5 text-center'>
                        <?php if(($booking->end_date->diffInDays($booking->start_date) + 1) == 1): ?>
                            <?php echo e($booking->end_date->diffInDays($booking->start_date) + 1); ?> Day
                        <?php else: ?> 
                            <?php echo e($booking->end_date->diffInDays($booking->start_date)  + 1); ?> Days
                        <?php endif; ?> 
                    </td>
                    <td class='text-center fs-5'>
                        <?php if($booking->downpayment_status === $downPaymentPaid): ?>
                            <button class='btn btn-success rounded-circle shadow'>
                                <i class='fas fa-check text-white'></i>
                            </button>
                        <?php endif; ?>
                    </td>
                    <td nowrap class='text-center fs-5'>
                        <?php echo e($booking->created_at->format('F d, Y h:i A')); ?>

                    </td>
                    <td class='text-center fs-5'>
                        <a href="<?php echo e(route('payment.success', $booking->id)); ?>" class='btn btn-info btn-lg'>PRINT</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>


</div>
<?php $__env->startPush('page-scripts'); ?>
<!-- Required datatable js -->
<script src="/admin-assets/libs/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="/admin-assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
<!-- Responsive examples -->
<script src="/admin-assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
<script src="/admin-assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>

<script>
    $("#bookings_table").DataTable();

</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\spacebar-book-system\resources\views/user/home.blade.php ENDPATH**/ ?>