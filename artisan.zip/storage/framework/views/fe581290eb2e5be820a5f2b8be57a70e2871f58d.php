<?php if($errors->any()): ?>
<!--begin::Alert-->
<div class="alert alert-dismissible bg-danger d-flex flex-column flex-sm-row">
    <!--begin::Wrapper-->
    <div class="d-flex flex-column text-light pe-0 pe-sm-10">
        <!--begin::Title-->
        <h5 class="mb-2 light text-white">
            <?php if($errors->count() !== 1): ?>
                    Please check these fields
                <?php else: ?>
                    Please check this fields
            <?php endif; ?>
        </h4>
        <!--end::Title-->

        <!--begin::Content-->
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class='mx-2'><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!--end::Content-->
    </div>
    <!--end::Wrapper-->

</div>
<!--end::Alert-->
<?php endif; ?>
<?php /**PATH C:\laragon\www\spacebar-book-system\resources\views/templates/errors.blade.php ENDPATH**/ ?>