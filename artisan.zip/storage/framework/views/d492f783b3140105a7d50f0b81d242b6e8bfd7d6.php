
<?php $__env->startSection('page-title', 'Facilities'); ?>
<?php $__env->startPrepend('page-css'); ?>
<?php $__env->stopPrepend(); ?>
<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-lg-6">
        <div class="text-center mb-5">
            <h4>Choose your Facility</h4>
            <p class="text-muted">We all live in an age that belongs to the young at heart. Life that is becoming
                extremely fast, </p>
        </div>
    </div>
</div>
<div class="row">
    <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-xl-4 col-md-6">
        <div class="card plan-box">
            <div class="card-body p-4">
                <div class="d-flex align-items-start">
                    <div class="flex-1 me-3">
                        <h5><?php echo e($room->name); ?></h5>
                        <p class="text-muted"><?php echo e(Str::limit($room->description, 15, '...')); ?></p>
                    </div>
                    <div class="ms-auto">
                        <i class="bx bx-home-circle h1 text-primary"></i>
                    </div>
                </div>
                <div class="py-4 mt-4 text-center bg-soft-light">
                    <h1 class="m-0"><sup><small>&#8369;</small></sup> <?php echo e((int) $room->price); ?>/ <span
                            class="font-size-13">Per
                            day</span></h1>
                </div>

                <div class="plan-features p-4 text-muted mt-2">
                    <p><i class="mdi mdi-check-bold text-primary me-4"></i><?php echo e($room->capacity); ?> Capacity</p>
                    <?php $__currentLoopData = explode(',', $room->description); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $description): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p><i class="mdi mdi-check-bold text-primary me-4"></i><?php echo e($description); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="text-center">
                    <a href="#" class="btn btn-warning waves-effect waves-light">View Images</a>
                    <a href="<?php echo e(route('user.booking.bookform', [$room->id])); ?>" class="btn btn-primary waves-effect waves-light">Book Now</a>
                </div>

            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('page-scripts'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\spacebar-book-system\resources\views/user/facilities.blade.php ENDPATH**/ ?>