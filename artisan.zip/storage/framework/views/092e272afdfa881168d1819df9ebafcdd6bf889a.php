
<?php $__env->startSection('page-title', 'Add new extra'); ?>
<?php $__env->startPrepend('page-css'); ?>
<?php $__env->stopPrepend(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('templates.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--begin::Container-->
<div class="">
    <!--begin::Card-->
    <div class="card">
        <!--begin::Card body-->
        <div class="card-body">
            <?php if($errors->any()): ?>
            <div class='alert alert-danger' style='list-style:none;'>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class='px-3'>
                    <?php echo e($error); ?>

                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
            <form action="<?php echo e(route('extras.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>


                <div class="form-group mb-3">
                    <label>Name</label>
                    <input type="text" class='form-control' name='name' value="<?php echo e(old('name')); ?>">
                </div>

                <div class="form-group mb-3">
                    <label>Description</label>
                    <input type="text" class='form-control' name='description' value="<?php echo e(old('description')); ?>">
                </div>

                <div class="form-group mb-3">
                    <label>Price</label>
                    <input type="number" class='form-control' name='price' value="<?php echo e(old('price')); ?>">
                </div>

                <div class="form-group mt-5 float-end">
                    <button type="submit" class='btn btn-primary'>Submit Extra</button>
                </div>
            </form>
        </div>
        <!--end::Card body-->
    </div>
    <!--end::Card-->
</div>
<!--end::Container-->

<?php $__env->stopSection(); ?>
<?php $__env->startPush('page-scripts'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\spacebar-book-system\resources\views/admin/extras/create.blade.php ENDPATH**/ ?>