
<?php $__env->startSection('page-title', 'Add New Room'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('templates.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if($errors->any()): ?>
<div class='alert alert-danger' style='list-style:none;'>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class='p-1'>
        <?php echo e($error); ?>

    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>
<div class="row">
    <div class="col-md-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <form action="<?php echo e(route('admin.room.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group mb-5">
                        <label>Name</label>
                        <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>"
                            placeholder="Enter room name">
                    </div>

                    <div class="form-group mb-5">
                        <label>Description</label>
                        <textarea name="description" class='form-control' cols="30" rows="10"
                            placeholder="Enter description"><?php echo e(old('description')); ?></textarea>
                    </div>

                    <div class="form-group mb-5">
                        <label>Capacity</label>
                        <input type="number" name="capacity" class="form-control" value="<?php echo e(old('capacity')); ?>"
                            placeholder="Enter room capacity">
                    </div>

                    <div class="form-group mb-5">
                        <label>Classification</label>
                        <select name="classification" class='form-control'>
                            <option value="" disabled></option>
                            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($type->id); ?>" <?php echo e(old('classification') == $type->id ? 'selected' : ''); ?>>
                                <?php echo e($type->type_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group mb-5">
                        <label>Type</label>
                        <select name="type" class='form-control'>
                            <option value="" disabled></option>
                            <option value="room" <?php echo e(old('type') == 'room' ? 'selected' : ''); ?>>Room</option>
                            <option value="cottage" <?php echo e(old('type') == 'cottage' ? 'selected' : ''); ?>>
                                Cottage</option>
                            <option value="function hall" <?php echo e(old('type') == 'function_hall' ? 'selected' : ''); ?>>
                                Function Hall</option>
                        </select>
                    </div>

                    <div class="form-group mb-5">
                        <label>Price</label>
                        <input type="number" name="price" class="form-control" value="<?php echo e(old('price')); ?>"
                            placeholder="Enter room price">
                    </div>


                    <div class="form-group mb-5" id='image-field-container'>
                        <label>Image</label>
                        <div class="float-end">
                            <button class='btn btn-success btn-sm' type='button' id='btnAddImageField'>Add</button>
                        </div>
                        <input name="image[]" type="file" class='form-control form-control-lg'>
                    </div>

                    <br>

                    <div class="form-group mb-5">
                        <label>Video</label>
                        <input name="video" type="file" class='form-control form-control-lg'>
                    </div>

                    <div class="form-group mb-5">
                        <div class="float-end">
                            <input type="submit" class='btn btn-primary' value='Create new room'>
                        </div>
                    </div>

                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->startPush('page-scripts'); ?>
<script>
    $('#btnAddImageField').click(function () {
        $('#image-field-container').append(`<input name="image[]" type="file" class='form-control form-control-lg mt-1'>`);
    });
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\spacebar-book-system\resources\views/admin/room/create.blade.php ENDPATH**/ ?>