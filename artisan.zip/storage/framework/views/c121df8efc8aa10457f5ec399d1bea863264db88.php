
<?php $__env->startSection('page-title', 'Content Management'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('templates.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
    <div class="col-md-12 grid-margin stretch-card">
        <a href="<?php echo e(route('admin.page.create')); ?>" class='btn btn-primary float-end shadow-sm mb-2'>ADD NEW CONTENT</a>
        <div class="clearfix"></div>
      <div class="card">
        <div class="card-body">
            <table class='table table-bordered table-hovered' id='users-table'>
                <thead>
                    <tr>
                        <th class='fw-bold text-uppercase'>
                            TITLE
                        </th>
                        <th class='fw-bold text-uppercase'>
                            CONTENT
                        </th>
                        <th class='fw-bold text-uppercase text-center'>
                            CREATED at
                        </th>
                        <th class='fw-bold text-uppercase text-center'>
                            Actions
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($content->title); ?></td>
                        <td><?php echo e($content->content); ?></td>
                        <td class='text-center'><?php echo e($content->created_at->format('F d, Y h:i A')); ?></td>
                        <td class='text-center' >
                            <form action="<?php echo e(route('admin.page.delete', $content->id)); ?>" method="POST">
                                <a href="<?php echo e(route('admin.page.edit', $content->id)); ?>" class='btn btn-success p-2 text-uppercase'>Edit</a>
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class='btn btn-danger p-2 text-uppercase'>Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </tbody>
            </table>
        </div>
      </div>
    </div>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\spacebar-book-system\resources\views/admin/page/index.blade.php ENDPATH**/ ?>