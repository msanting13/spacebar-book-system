
<?php $__env->startSection('page-title', 'Generate Reports'); ?>
<?php $__env->startPrepend('page-css'); ?>
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
<style>
</style>
<?php $__env->stopPrepend(); ?>
<?php $__env->startSection('content'); ?>

<!--begin::Container-->
    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('reports.create')); ?>" method="GET">
                <div class="form-group">
                    <label for="" class='lead fw-bold mb-2 mx-2'>Pick Date Range</label>
                    <input type="text" name='daterange' class='form-control form-control-lg form-control-solid'>
                </div>
                <div class="form-group float-end mt-5">
                    <input type="submit" class='btn btn-primary shadow' value="Generate">
                </div>
            </form>

            <div class="clearfix"></div>

            <?php if(isset($bookings)): ?>
            <hr>
                <div class="card">
                    <!--begin:Card header-->
                    <div class="card-header">
                        <table id="kt_orders_classic" class="table table-row-bordered table-row-dashed align-middle">
                            <thead class=" fw-boldest text-gray-400 text-uppercase">
                                <tr>
                                    <th class="min-w-200px text-dark">TOTAL ROOMS</th>
                                    <th class="min-w-150px text-dark text-center">EXTRAS TOTAL AMOUNT</th>
                                    <th class="min-w-200px text-dark text-center">ROOM TOTAL AMOUNT</th>
                                    <th class="min-w-100px text-dark  text-center">TOTAL DAYS CUSTOMER STAYED</th>
                                </tr>
                            </thead>
                            <tbody class=" fw-boldest">
                                <tr>
                                    <td>
                                        <span class='mx-5 display-5'>
                                            <?php echo e($bookings->count()); ?>

                                        </span>
                                    </td>
                                    <td class='text-center'>
                                        <span class='mx-5 display-5'>
                                        &#8369; <?php echo e(number_format($extrasTotal, 2, ".", ",")); ?>

                                        </span>
                                    </td>
                                    <td class='text-center'>
                                        <span class='mx-5 display-5'>
                                        &#8369; <?php echo e(number_format($total, 2, ".", ",")); ?>

                                        </span>
                                    </td>
                                    <td class='text-center'>
                                        <span class='mx-5 display-5'>
                                        <?php echo e($totalStayedDays); ?>

                                        </span>
                                    </td>
                                    
                                    
                                    <td>
                                        
                                    </td>
                                </tr>
                         
                            </tbody>
                        </table>
                    </div>
                    <!--end:Card header-->
                    <!--begin:Card body-->
                    <div class="card-body">
                        <!--begin::Table-->
                        <table id="kt_orders_classic" class="table table-row-bordered table-row-dashed g-3 gs-0 align-middle">
                            <thead class="fw-boldest text-gray-400 text-uppercase">
                                <tr>
                                    <th class="min-w-200px text-dark">Room</th>
                                    <th class="min-w-150px text-dark">EXTRAS</th>
                                    <th class="min-w-150px text-dark">EXTRAS AMOUNT</th>
                                    <th class="min-w-100px text-dark">room Amount</th>
                                    <th class="min-w-100px text-dark">stayed date</th>
                                    <th class="min-w-100px text-dark text-center">stayed days</th>
                                    <th class="min-w-100px text-dark text-center">sub-total</th>
                                </tr>
                            </thead>
                            <tbody class=" fw-boldest">
                                <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <!--begin::Wrapper-->
                                        <div class="d-flex">
                                            <!--begin::Image-->
                                            <div class="symbol symbol-75px me-6 bg-light">
                                                <?php if($booking->room->image->count() != 0): ?>
                                                    <img src="<?php echo e(asset('/storage/uploads/' . $booking->room->image->first()->photo)); ?>" height="275px"
                                                        alt="">
                                                    <?php else: ?>
                                                    <img src="<?php echo e(asset('/theme/royal/image/xroom1.jpg.pagespeed.ic.GE_Jw5sZi4.jpg')); ?>" alt="">
                                                <?php endif; ?>
                                            </div>
                                            <!--end::Image-->
                                            <!--begin::Info-->
                                            <div class="d-flex flex-column justify-content-center">
                                                <a href="#" class="mb-1 text-gray-800 text-hover-primary"><?php echo e($booking->room->name); ?></a>
                                                <div class="fw-bold text-gray-400 text-uppercase"><?php echo e(Str::limit($booking->id, 8 , '')); ?></div>
                                            </div>
                                            <!--end::Info-->
                                        </div>
                                        <!--end::Wrapper-->
                                    </td>
                                     <td class='text-uppercase'>
                                        <?php echo e($booking->extras->implode('name', ', ')); ?>

                                    </td>
                                    <td>&#8369;<?php echo e(number_format($booking->extras->sum('price') , 2, ".", ",")); ?></td>
                                    <td>&#8369;<?php echo e(number_format($booking->room->price, 2, ".", ",")); ?></td>
                                    <td><?php echo e($booking->start_date->format('F d ')); ?> - <?php echo e($booking->end_date->format('d Y')); ?></td>
                                    <?php if($booking->start_date->diffInDays($booking->end_date) == 0): ?>
                                        <td class='text-center'>1</td>
                                    <?php else: ?>
                                        <td class='text-center'><?php echo e($booking->start_date->diffInDays($booking->end_date)); ?></td>
                                    <?php endif; ?>
                                    <?php
                                        $stayedDays = $booking->start_date->diffInDays($booking->end_date) == 0 ? 1 : $booking->start_date->diffInDays($booking->end_date)
                                    ?>
                                    <td class='text-center'>
                                       <?php echo e(number_format($stayedDays * $booking->room->price + $booking->extras->sum('price'), 2, ".", ",")); ?>

                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <!--end::Table-->
                    </div>
                    <!--end:Card body-->
                    <a href="#" class='btn btn-info shadow'>
                        PRINT
                    </a>

                </div>
                
            <?php endif; ?>

            
        </div>
    </div>
<!--end::Container-->

<?php $__env->stopSection(); ?>
<?php $__env->startPush('page-scripts'); ?>
<script type="text/javascript" src="https://cdn.jsdelivr.net/jquery/latest/jquery.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
<script>
    $(function () {
        $('#minimixe-sidebar').trigger('click');
        
        $('input[name="daterange"]').daterangepicker({
            opens: 'left'
        }, function (start, end, label) {
            console.log("A new date selection was made: " + start.format('YYYY-MM-DD') + ' to ' + end
                .format('YYYY-MM-DD'));
        });
    });

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\spacebar-book-system\resources\views/admin/report/index.blade.php ENDPATH**/ ?>